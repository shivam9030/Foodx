export const EMAIL = {
  value: /^[\w-.]+@([\w-]+\.)+[\w-]{2,63}$/i,
  message: 'Email Is Not Valid',
};
